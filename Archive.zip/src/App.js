import React from 'react';
import './App.css';
import Home from './components/home';

function App() {
  return (
    <div className="App">
    <Home style={{margin:'0px auto'}}/>
    </div>
  );
}

export default App;
